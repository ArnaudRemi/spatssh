# config file for the spatssh server.

# "username": "password"
users = {'foo': 'bar',
         'root': 'toor',
         'tutu': 'toto',
         'remi': 'coucou'}

# "servername": ("ip", port)
servers = {"sshPort22": ("127.0.0.1", 22),
           "sshPort2200": ("127.0.0.1", 2200)}
